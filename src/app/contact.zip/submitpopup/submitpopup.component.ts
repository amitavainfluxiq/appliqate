import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-submitpopup',
  templateUrl: './submitpopup.component.html',
  styleUrls: ['./submitpopup.component.css']
})
export class SubmitpopupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
